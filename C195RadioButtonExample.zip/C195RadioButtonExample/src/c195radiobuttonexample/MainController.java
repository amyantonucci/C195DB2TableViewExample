/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c195radiobuttonexample;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;

/**
 * FXML Controller class
 *
 * @author shoikana
 */
public class MainController implements Initializable {

    
    //These radio buttons are grouped in SceneBuilder on the radio button's property window under Toggle Group
    //Enter any value in for the first radio button, and then choose that same value for the other radio buttons that
    //you want to be grouped together
    
  //Only one button in the group will be chosen at a particular time
    @FXML
    private RadioButton rdoBlue;

    @FXML
    private RadioButton rdoYellow;

    @FXML
    private RadioButton rdoRed;

    @FXML
    private Label lblMsg;
@FXML
    private AnchorPane anchor;

    @FXML
    void handleRed(ActionEvent event) {
        lblMsg.setText("You chose red!");
        anchor.setBackground(new Background(new BackgroundFill(Color.RED, null, null)));
    }

    @FXML
    void handleYellow(ActionEvent event) {
        lblMsg.setText("You chose yellow!");
        anchor.setBackground(new Background(new BackgroundFill(Color.YELLOW, null, null)));
    }

    @FXML
    void handleBlue(ActionEvent event) {
        lblMsg.setText("You chose blue!");
        anchor.setBackground(new Background(new BackgroundFill(Color.BLUE, null, null)));
    }

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
